$(function() {

	$('#menu-btn').click(function() {
		$('#menu-head').toggleClass("open");
		return false;
	});
	$('#login-btn').click(function() {
		$('#lg-dialog').toggleClass("open");
		return false;
	});
	$('#lg-close').click(function() {
		$('#lg-dialog').removeClass("open");
		return false;
	});

});